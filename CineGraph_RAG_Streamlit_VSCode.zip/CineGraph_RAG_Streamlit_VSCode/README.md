# 🎬 CineGraph RAG — Neo4j Movie Knowledge Assistant

A complete mini-project for the requirement:

> Design and implement a small RAG application that uses the Neo4j Movies dataset as a knowledge graph, retrieves relevant movie/actor/director information via Cypher queries, and generates natural-language answers.

This package is intentionally **self-contained**. It includes a small curated movie graph dataset so you can demonstrate the project without downloading another dataset.

## 1. What is included?

- `data/` — bundled CSV dataset: movies, actors, directors and genres.
- `cypher/seed.cypher` — creates the Neo4j graph and loads all CSVs.
- `cypher/query_templates.cypher` — reusable Cypher queries.
- `app/app.py` — professional Streamlit web interface.
- `.env.example` — Neo4j connection configuration template.
- `docs/Question_Guide.md` — exact questions to demonstrate.
- `docs/Project_Report.md` — report-ready explanation.
- `requirements.txt` — Python dependencies.

## 2. Tools required

### Required
1. Python 3.10+ (Python 3.11 or 3.12 recommended)
2. Neo4j Desktop **or** Neo4j AuraDB
3. A web browser
4. VS Code / PyCharm (recommended)

### Python packages
- Streamlit — web UI
- neo4j — official Neo4j Python driver
- python-dotenv — `.env` configuration
- openai — optional extension if you later add an LLM response layer

## 3. Recommended easiest setup: Neo4j Desktop

1. Install Neo4j Desktop.
2. Create a local DBMS.
3. Set username to `neo4j` and create a password.
4. Start the DBMS.
5. Open Neo4j Browser.
6. Copy the four CSV files from `data/` into Neo4j's import directory if Neo4j asks for a file URL location.
7. Open `cypher/seed.cypher` and run it.

If using AuraDB, upload/import the CSV data and run the Cypher statements in the Aura Query console. For Aura, you may prefer importing the CSVs through the Aura import workflow.

## 4. Python environment

Open a terminal in this project folder:

### Windows PowerShell
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

If PowerShell blocks activation:
```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 5. Configure Neo4j

Copy:
```text
.env.example
```
to:
```text
.env
```

For AuraDB:
```env
NEO4J_URI=neo4j+s://your-instance.databases.neo4j.io
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your_password
```

For a local Neo4j server, use the Bolt URI shown by your installation, commonly:
```env
NEO4J_URI=bolt://localhost:7687
```

Never upload your real `.env` file to GitHub.

## 6. Start the application

```powershell
streamlit run app/app.py
```

A browser page will open. If it does not, open the local URL printed in the terminal.

## 7. Demo flow for your review/viva

1. Show the Neo4j graph.
2. Explain nodes:
   - Movie
   - Person
   - Genre
3. Explain relationships:
   - `DIRECTED`
   - `ACTED_IN`
   - `IN_GENRE`
4. Open the Streamlit page.
5. Ask:
   - Who directed Inception?
   - Who acted in The Dark Knight?
   - Movies directed by Christopher Nolan
   - Movies featuring Leonardo DiCaprio
   - Recommend movies similar to Inception
6. Show the retrieved rows.
7. Explain that the final answer is grounded in the retrieved graph facts rather than being invented from model memory.

## 8. Important architecture

```text
User question
     ↓
Question understanding
     ↓
Intent + entity detection
     ↓
Cypher template selection
     ↓
Neo4j graph retrieval
     ↓
Relevant movie/person/genre facts
     ↓
Natural-language answer
     ↓
Streamlit UI
```

### Optional LLM upgrade

For a stronger "LLM + Graph RAG" version, add an LLM after Neo4j retrieval:

```text
User question
   ↓
LLM / structured intent parser
   ↓
Cypher query
   ↓
Neo4j
   ↓
Context / retrieved facts
   ↓
LLM answer generation
   ↓
UI
```

The project is runnable without an API key. If `OPENAI_API_KEY` is added, the app uses the retrieved Neo4j rows as grounded context for LLM-generated natural-language answers.

## 9. Optional LLM setup

Add these to `.env` if your faculty specifically wants the LLM generation layer enabled:
```env
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4.1-mini
```
The application still retrieves facts from Neo4j first. The LLM is instructed to answer only from those retrieved facts.

## 10. Expected result

The application should:
- load the Neo4j movie graph,
- translate supported natural-language questions into graph operations,
- retrieve relevant graph facts,
- present grounded answers,
- provide movie recommendations using shared genres/cast,
- expose the underlying retrieved facts for transparency.

## 11. Troubleshooting

### "Neo4j is not configured"
Check `.env` and restart Streamlit.

### CSV import error
For local Neo4j, ensure the CSV files are in Neo4j's configured import directory. For AuraDB, use its supported import/upload workflow.

### Wrong password
Reset/update the Neo4j password and update `.env`.

### Port already used
Run:
```powershell
streamlit run app/app.py --server.port 8502
```

## 12. Academic note

This is a graph-based RAG prototype, not a large-scale production recommender. Its purpose is to demonstrate:
- knowledge graph representation,
- Cypher retrieval,
- natural-language question answering,
- grounded generation architecture,
- recommendation using graph relationships.
