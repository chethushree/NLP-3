@echo off
title CineGraph RAG - Streamlit
cd /d "%~dp0"
if not exist .venv (
    echo Creating Python virtual environment...
    python -m venv .venv
)
echo Installing required packages...
.venv\Scripts\python.exe -m pip install -r requirements.txt
echo.
echo Starting CineGraph RAG...
.venv\Scripts\python.exe -m streamlit run app\app.py
pause
