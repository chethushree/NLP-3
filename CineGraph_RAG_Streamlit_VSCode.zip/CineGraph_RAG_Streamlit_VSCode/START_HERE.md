# START HERE — CineGraph RAG Streamlit

## Fastest way (VS Code + Streamlit)

1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app\app.py
```

5. Open the `Local URL` shown by Streamlit, usually:
`http://localhost:8501`

### IMPORTANT
This version runs immediately using the bundled movie CSV files even if Neo4j is not configured.

For the full Neo4j demonstration:
1. Start Neo4j Desktop/AuraDB.
2. Load the CSV files from `data/`.
3. Run `cypher/seed.cypher`.
4. Copy `.env.example` to `.env`.
5. Put your Neo4j password in `.env`.
6. Restart Streamlit.

When Neo4j is connected, the sidebar changes to **Neo4j connected**.

## Questions to demonstrate

- Who directed Inception?
- Who acted in The Dark Knight?
- Recommend movies similar to Inception
- Movies directed by Christopher Nolan
- Movies featuring Leonardo DiCaprio
- Show action movies
- What movies are in 2014?

## If PowerShell activation is blocked

Run:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m streamlit run app\app.py
```

## Optional LLM

Put your API key in `.env`:

```env
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4.1-mini
```

The graph is still the source of retrieved facts.
