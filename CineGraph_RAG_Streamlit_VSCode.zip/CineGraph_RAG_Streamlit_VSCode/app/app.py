
import os, re, json
from pathlib import Path
from typing import Dict, Any, List, Tuple

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

try:
    from neo4j import GraphDatabase
except Exception:
    GraphDatabase = None

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

st.set_page_config(
    page_title="CineGraph RAG",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------- CSS ----------------
st.markdown("""
<style>
.main .block-container {max-width:1200px;padding-top:2rem;padding-bottom:3rem}
.hero{padding:2.3rem 2.5rem;border-radius:25px;background:linear-gradient(135deg,#0f172a,#1e293b 55%,#3730a3);color:white;margin-bottom:1.5rem;box-shadow:0 16px 45px rgba(15,23,42,.18)}
.hero h1{font-size:2.7rem;margin:0 0 .4rem;letter-spacing:-.05em}
.hero p{margin:0;color:#dbeafe;font-size:1.05rem}
.badge{display:inline-block;padding:.35rem .7rem;border:1px solid #ffffff35;border-radius:999px;font-size:.78rem;margin-bottom:.8rem;background:#ffffff12}
.answer{background:#f8fafc;border-left:4px solid #4f46e5;padding:1rem 1.2rem;border-radius:12px}
.card{background:white;border:1px solid #e2e8f0;border-radius:18px;padding:1.1rem 1.2rem;margin:.5rem 0}
.small{color:#64748b;font-size:.88rem}
</style>
""", unsafe_allow_html=True)

DATA = ROOT / "data"
movies = pd.read_csv(DATA / "movies.csv")
actors = pd.read_csv(DATA / "actors.csv")
directors = pd.read_csv(DATA / "directors.csv")
genres = pd.read_csv(DATA / "genres.csv")

# ---------------- Neo4j ----------------
@st.cache_resource
def get_driver():
    if GraphDatabase is None:
        return None
    uri = os.getenv("NEO4J_URI", "")
    username = os.getenv("NEO4J_USERNAME", "neo4j")
    password = os.getenv("NEO4J_PASSWORD", "")
    if not uri or not password:
        return None
    try:
        d = GraphDatabase.driver(uri, auth=(username, password))
        d.verify_connectivity()
        return d
    except Exception:
        return None

driver = get_driver()

def neo4j_query(cypher, params=None):
    with driver.session() as session:
        return [dict(r) for r in session.run(cypher, params or {})]

# ---------------- Local graph fallback ----------------
def local_query(intent, value=None):
    if intent == "director":
        rows = directors[directors.movie.str.lower() == value.lower()]
        return [{"director": x} for x in rows.name.tolist()]
    if intent == "cast":
        rows = actors[actors.movie.str.lower() == value.lower()]
        return [{"actor": x} for x in rows.name.tolist()]
    if intent == "filmography":
        rows = directors[directors.name.str.lower() == value.lower()].merge(
            movies, left_on="movie", right_on="title"
        )
        return [{"movie":r.movie,"year":int(r.year),"rating":float(r.rating)} for _,r in rows.iterrows()]
    if intent == "actor_movies":
        rows = actors[actors.name.str.lower() == value.lower()].merge(
            movies, left_on="movie", right_on="title"
        ).sort_values("rating", ascending=False)
        return [{"movie":r.movie,"year":int(r.year),"rating":float(r.rating)} for _,r in rows.iterrows()]
    if intent == "genre":
        rows = genres[genres.genre.str.lower() == value.lower()].merge(
            movies, left_on="movie", right_on="title"
        ).sort_values("rating", ascending=False).head(10)
        return [{"movie":r.movie,"year":int(r.year),"rating":float(r.rating)} for _,r in rows.iterrows()]
    if intent == "year":
        rows = movies[movies.year == int(value)].sort_values("rating", ascending=False)
        return [{"movie":r.title,"rating":float(r.rating)} for _,r in rows.iterrows()]
    if intent == "recommend":
        seed = movies[movies.title.str.lower() == value.lower()]
        if seed.empty: return []
        title = seed.iloc[0].title
        gs = set(genres[genres.movie == title].genre)
        cast = set(actors[actors.movie == title].name)
        out = []
        for _,m in movies.iterrows():
            if m.title == title: continue
            mg = set(genres[genres.movie == m.title].genre)
            mc = set(actors[actors.movie == m.title].name)
            sg, sa = len(gs & mg), len(cast & mc)
            score = sg*2 + sa + float(m.rating)/10
            if sg or sa:
                out.append({"movie":m.title,"year":int(m.year),"rating":float(m.rating),
                            "sharedGenres":sg,"sharedActors":sa,"score":score})
        return sorted(out,key=lambda x:(x["score"],x["rating"]),reverse=True)[:5]
    return []

MOVIE_ALIASES = {
    "fellowship":"The Lord of the Rings: The Fellowship of the Ring",
    "lotr":"The Lord of the Rings: The Fellowship of the Ring",
    "dark knight":"The Dark Knight","matrix":"The Matrix","inception":"Inception",
    "interstellar":"Interstellar","dunkirk":"Dunkirk","tenet":"Tenet","memento":"Memento",
    "prestige":"The Prestige","titanic":"Titanic","revenant":"The Revenant",
    "shutter island":"Shutter Island","wolf of wall street":"The Wolf of Wall Street",
    "catch me if you can":"Catch Me If You Can","departed":"The Departed",
    "goodfellas":"Goodfellas","gladiator":"Gladiator","shawshank":"The Shawshank Redemption",
    "forrest gump":"Forrest Gump","social network":"The Social Network",
    "grand budapest":"The Grand Budapest Hotel","parasite":"Parasite","whiplash":"Whiplash",
    "la la land":"La La Land","mad max":"Mad Max: Fury Road","avatar":"Avatar",
    "jurassic park":"Jurassic Park","truman show":"The Truman Show","martian":"The Martian",
    "arrival":"Arrival"
}
PEOPLE = sorted(set(directors.name.tolist()+actors.name.tolist()), key=len, reverse=True)
GENRES = sorted(genres.genre.unique().tolist(), key=len, reverse=True)

def find_movie(q):
    low=q.lower()
    for alias,title in sorted(MOVIE_ALIASES.items(), key=lambda x:len(x[0]), reverse=True):
        if alias in low: return title
    for title in movies.title:
        if title.lower() in low: return title
    return None

def find_person(q):
    low=q.lower()
    for p in PEOPLE:
        if p.lower() in low: return p
    return None

def get_facts(intent, value):
    if driver:
        if intent=="director":
            return neo4j_query("MATCH (p:Person)-[:DIRECTED]->(m:Movie {title:$title}) RETURN p.name AS director",{"title":value})
        if intent=="cast":
            return neo4j_query("MATCH (p:Person)-[:ACTED_IN]->(m:Movie {title:$title}) RETURN p.name AS actor ORDER BY actor",{"title":value})
        if intent=="filmography":
            return neo4j_query("MATCH (p:Person {name:$name})-[:DIRECTED]->(m:Movie) RETURN m.title AS movie,m.year AS year,m.rating AS rating ORDER BY year DESC",{"name":value})
        if intent=="actor_movies":
            return neo4j_query("MATCH (p:Person {name:$name})-[:ACTED_IN]->(m:Movie) RETURN m.title AS movie,m.year AS year,m.rating AS rating ORDER BY rating DESC",{"name":value})
        if intent=="genre":
            return neo4j_query("MATCH (m:Movie)-[:IN_GENRE]->(g:Genre) WHERE toLower(g.name)=toLower($genre) RETURN m.title AS movie,m.year AS year,m.rating AS rating ORDER BY rating DESC LIMIT 10",{"genre":value})
        if intent=="year":
            return neo4j_query("MATCH (m:Movie {year:$year}) RETURN m.title AS movie,m.rating AS rating ORDER BY rating DESC",{"year":int(value)})
        if intent=="recommend":
            return neo4j_query("""MATCH (seed:Movie {title:$title})-[:IN_GENRE]->(g:Genre)<-[:IN_GENRE]-(rec:Movie)
            WHERE rec<>seed OPTIONAL MATCH (seed)<-[:ACTED_IN]-(shared:Person)-[:ACTED_IN]->(rec)
            WITH rec,count(DISTINCT g) AS sharedGenres,count(DISTINCT shared) AS sharedActors
            RETURN rec.title AS movie,rec.year AS year,rec.rating AS rating,sharedGenres,sharedActors,
            (sharedGenres*2+sharedActors+coalesce(rec.rating,0)/10.0) AS score
            ORDER BY score DESC,rating DESC LIMIT 5""",{"title":value})
    return local_query(intent,value)

def answer_question(question):
    q=question.strip()
    low=q.lower()
    movie=find_movie(q)
    person=find_person(q)

    if any(x in low for x in ["who directed","director of","directed by whom"]) and movie:
        rows=get_facts("director",movie)
        if rows: return f"**{movie}** was directed by **{rows[0]['director']}**.","Director",rows

    if any(x in low for x in ["who acted","cast of","actors in","who stars"]) and movie:
        rows=get_facts("cast",movie)
        names=[r["actor"] for r in rows]
        if names: return f"The graph lists these cast members for **{movie}**: "+", ".join(names)+".","Cast",rows

    if any(x in low for x in ["recommend","similar","like"]) and movie:
        rows=get_facts("recommend",movie)
        if rows:
            names=", ".join(f"**{r['movie']}** ({r['year']})" for r in rows)
            return f"Based on shared genres and cast connections, the graph suggests: {names}.","Recommendation",rows

    if person and any(x in low for x in ["movies by","films by","filmography"]):
        rows=get_facts("filmography",person)
        return f"Movies directed by **{person}**: "+", ".join(r["movie"] for r in rows)+".","Filmography",rows

    if person and any(x in low for x in ["movies with","films with","movies featuring","acted in"]):
        rows=get_facts("actor_movies",person)
        return f"Movies featuring **{person}**: "+", ".join(r["movie"] for r in rows)+".","Actor Movies",rows

    gm=next((g for g in GENRES if g.lower() in low),None)
    if gm and ("movie" in low or "film" in low):
        rows=get_facts("genre",gm)
        return f"Top **{gm}** movies: "+", ".join(r["movie"] for r in rows)+".","Genre",rows

    ym=re.search(r"\b(19\d{2}|20\d{2})\b",low)
    if ym and ("movie" in low or "film" in low):
        rows=get_facts("year",ym.group(1))
        return f"Movies from **{ym.group(1)}**: "+(", ".join(r["movie"] for r in rows) if rows else "none in the graph.") ,"Year",rows

    return ("Try one of the supported examples in the sidebar.","Help",[])

def llm_generate(question, rows, fallback):
    key=os.getenv("OPENAI_API_KEY","")
    model=os.getenv("OPENAI_MODEL","gpt-4.1-mini")
    if not key or OpenAI is None or not rows: return fallback
    try:
        client=OpenAI(api_key=key)
        response=client.responses.create(
            model=model,
            input=[
                {"role":"system","content":"Answer only from the supplied Neo4j facts. Do not invent information. If facts are insufficient, say so. Keep it concise."},
                {"role":"user","content":f"Question: {question}\nRetrieved Neo4j facts: {json.dumps(rows,default=str)}"}
            ])
        return response.output_text.strip() or fallback
    except Exception:
        return fallback

# ---------------- Page ----------------
st.markdown("""
<div class="hero">
<div class="badge">NEO4J • GRAPH RAG • STREAMLIT</div>
<h1>🎬 CineGraph RAG</h1>
<p>Ask natural-language questions about movies, actors, directors and genres using a Neo4j knowledge graph.</p>
</div>
""",unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## ⚙️ System")
    if driver:
        st.success("Neo4j connected")
        source="Neo4j"
    else:
        st.info("Demo mode: bundled dataset")
        source="Local CSV graph"
    st.caption(f"Retrieval source: **{source}**")
    st.divider()
    st.markdown("## 💡 Try these questions")
    examples=[
        "Who directed Inception?",
        "Who acted in The Dark Knight?",
        "Recommend movies similar to Inception",
        "Movies directed by Christopher Nolan",
        "Movies featuring Leonardo DiCaprio",
        "Show action movies",
        "What movies are in 2014?"
    ]
    for e in examples:
        if st.button(e,use_container_width=True):
            st.session_state["q"]=e
    st.divider()
    st.markdown("### Graph schema")
    st.code("(Person)-[:DIRECTED]->(Movie)\n(Person)-[:ACTED_IN]->(Movie)\n(Movie)-[:IN_GENRE]->(Genre)")

st.markdown("### 🔎 Ask the movie graph")
q=st.text_input("Your question",value=st.session_state.get("q",""),placeholder="Example: Recommend movies similar to Inception")

c1,c2=st.columns([1,1])
with c1: ask=st.button("🔎 Ask",type="primary",use_container_width=True)
with c2: clear=st.button("↺ Clear",use_container_width=True)

if clear:
    st.session_state["q"]=""
    st.rerun()

if ask and q:
    answer,mode,rows=answer_question(q)
    final=llm_generate(q,rows,answer)
    st.markdown("### Answer")
    st.markdown(f'<div class="answer">{final}</div>',unsafe_allow_html=True)
    generation="LLM + Neo4j" if os.getenv("OPENAI_API_KEY") and driver else "Graph-grounded"
    st.markdown(f'<div class="small">Mode: <b>{mode}</b> · Source: <b>{source}</b> · Generation: <b>{generation}</b></div>',unsafe_allow_html=True)
    if rows:
        st.markdown("### 📊 Retrieved graph facts")
        st.dataframe(pd.DataFrame(rows),use_container_width=True,hide_index=True)

st.divider()
st.markdown("### 📖 About this project")
st.markdown("""
<div class="card">
<b>RAG flow:</b> Natural-language question → graph retrieval → relevant facts → grounded answer.
<br><br>
<b>Academic objective:</b> demonstrate Neo4j knowledge graphs, Cypher retrieval, graph-based recommendations and an optional LLM generation layer.
</div>
""",unsafe_allow_html=True)

st.caption("CineGraph RAG · Educational project · Bundled dataset included")
