# Optional LLM extension

The current `app.py` already includes an optional OpenAI generation layer. Set `OPENAI_API_KEY` in `.env` to enable it. Without the key, the deterministic Neo4j-grounded answers remain available.

The baseline app does not require an LLM API key. To turn it into a full LLM + Graph RAG pipeline:

1. Detect intent/entities or ask the LLM to return a strict JSON object.
2. Map the structured intent to an allow-listed Cypher template.
3. Execute only read-only, parameterized Cypher.
4. Pass the retrieved rows to the LLM.
5. Prompt the LLM to answer only from retrieved context.
6. Display the Cypher and retrieved facts for transparency.

Example context:
```text
Question: Who directed Inception?
Retrieved facts:
director = Christopher Nolan
```

Example answer instruction:
```text
Answer the user's question using only the retrieved facts.
If the facts do not contain the answer, say that the graph does not contain enough information.
Do not invent names or relationships.
```
