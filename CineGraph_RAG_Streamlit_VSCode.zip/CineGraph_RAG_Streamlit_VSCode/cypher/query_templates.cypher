// Query templates used by the application

// 1. Director of a movie
MATCH (p:Person)-[:DIRECTED]->(m:Movie {title: $title})
RETURN p.name AS director;

// 2. Cast of a movie
MATCH (p:Person)-[:ACTED_IN]->(m:Movie {title: $title})
RETURN p.name AS actor
ORDER BY actor;

// 3. Movies by a director
MATCH (p:Person {name: $name})-[:DIRECTED]->(m:Movie)
RETURN m.title AS movie, m.year AS year, m.rating AS rating
ORDER BY year DESC;

// 4. Movies featuring an actor
MATCH (p:Person {name: $name})-[:ACTED_IN]->(m:Movie)
RETURN m.title AS movie, m.year AS year, m.rating AS rating
ORDER BY rating DESC;

// 5. Movies by genre
MATCH (m:Movie)-[:IN_GENRE]->(g:Genre {name: $genre})
RETURN m.title AS movie, m.year AS year, m.rating AS rating
ORDER BY rating DESC;

// 6. Movies in a year
MATCH (m:Movie {year: $year})
RETURN m.title AS movie, m.rating AS rating
ORDER BY rating DESC;

// 7. Recommendations using shared genres and actors
MATCH (seed:Movie {title: $title})-[:IN_GENRE]->(g:Genre)<-[:IN_GENRE]-(rec:Movie)
WHERE rec <> seed
OPTIONAL MATCH (seed)<-[:ACTED_IN]-(shared:Person)-[:ACTED_IN]->(rec)
WITH rec, count(DISTINCT g) AS sharedGenres, count(DISTINCT shared) AS sharedActors
RETURN rec.title AS movie, rec.year AS year, rec.rating AS rating,
       sharedGenres, sharedActors,
       (sharedGenres * 2 + sharedActors + coalesce(rec.rating,0)/10.0) AS score
ORDER BY score DESC, rating DESC
LIMIT 5;

// 8. Graph overview
MATCH (m:Movie)
RETURN count(m) AS movie_count,
       count { (p:Person) } AS people_count,
       count { (g:Genre) } AS genre_count;
