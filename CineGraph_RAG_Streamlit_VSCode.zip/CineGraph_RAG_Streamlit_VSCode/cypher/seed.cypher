// Neo4j Movie RAG - database seed
// Run this file in Neo4j Browser / Desktop / AuraDB Query.

CREATE CONSTRAINT movie_title IF NOT EXISTS
FOR (m:Movie) REQUIRE m.title IS UNIQUE;

CREATE CONSTRAINT person_name IF NOT EXISTS
FOR (p:Person) REQUIRE p.name IS UNIQUE;

CREATE CONSTRAINT genre_name IF NOT EXISTS
FOR (g:Genre) REQUIRE g.name IS UNIQUE;

LOAD CSV WITH HEADERS FROM 'file:///movies.csv' AS row
MERGE (m:Movie {title: row.title})
SET m.year = toInteger(row.year),
    m.rating = toFloat(row.rating),
    m.runtime = toInteger(row.runtime),
    m.tagline = row.tagline;

LOAD CSV WITH HEADERS FROM 'file:///directors.csv' AS row
MATCH (m:Movie {title: row.movie})
MERGE (p:Person {name: row.name})
MERGE (p)-[:DIRECTED]->(m);

LOAD CSV WITH HEADERS FROM 'file:///actors.csv' AS row
MATCH (m:Movie {title: row.movie})
MERGE (p:Person {name: row.name})
MERGE (p)-[:ACTED_IN]->(m);

LOAD CSV WITH HEADERS FROM 'file:///genres.csv' AS row
MATCH (m:Movie {title: row.movie})
MERGE (g:Genre {name: row.genre})
MERGE (m)-[:IN_GENRE]->(g);

CREATE INDEX movie_year IF NOT EXISTS FOR (m:Movie) ON (m.year);
CREATE INDEX movie_rating IF NOT EXISTS FOR (m:Movie) ON (m.rating);

MATCH (m:Movie)
RETURN count(m) AS movies;

MATCH (p:Person)
RETURN count(p) AS people;

MATCH (g:Genre)
RETURN count(g) AS genres;
