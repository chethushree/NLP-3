# Project Report — CineGraph RAG

## Title
**CineGraph RAG: Natural-Language Movie Question Answering using Neo4j Knowledge Graphs**

## Abstract
This project implements a small Retrieval-Augmented Generation style application over a Neo4j movie knowledge graph. Movie, person and genre information is stored as connected graph entities. User questions are interpreted into structured intents and resolved through Cypher graph queries. The retrieved facts are then presented as concise natural-language answers in a Streamlit web interface. A recommendation query demonstrates graph-based discovery using shared genres and cast members.

## Problem Statement
Traditional keyword search can retrieve isolated movie records but does not naturally represent relationships such as "who acted in a movie directed by a particular director". A graph database can model these relationships directly and make multi-hop retrieval easier.

## Objectives
1. Build a Neo4j movie knowledge graph.
2. Store movies, people and genres with meaningful relationships.
3. Convert natural-language questions into graph retrieval operations.
4. Return grounded answers from Neo4j.
5. Demonstrate basic graph-based movie recommendations.
6. Provide a clean web interface for demonstration.

## Knowledge Graph Schema

### Nodes
- `Movie`: title, year, rating, runtime, tagline
- `Person`: name
- `Genre`: name

### Relationships
- `(Person)-[:DIRECTED]->(Movie)`
- `(Person)-[:ACTED_IN]->(Movie)`
- `(Movie)-[:IN_GENRE]->(Genre)`

## Architecture
User → Question Understanding → Cypher Retrieval → Neo4j → Retrieved Context → Answer Generation → Streamlit

## Methodology

### 1. Data preparation
A small curated movie dataset is bundled with the project. CSV files are used for reproducible import.

### 2. Graph construction
Neo4j constraints and Cypher `MERGE` statements create nodes and relationships.

### 3. Question understanding
The prototype identifies supported intents and entities such as movie titles and person names.

### 4. Retrieval
Parameterized Cypher queries retrieve facts from the graph.

### 5. Answer generation
The application converts retrieved rows into natural-language responses. A deterministic baseline is always available. When an OpenAI API key is configured, the retrieved Neo4j facts are passed to an LLM, which generates the final natural-language response while being instructed not to invent information.

### 6. Recommendation
The recommendation query finds movies sharing genres with the selected movie and gives an additional signal when cast members overlap.

## Example Interaction

Question:
> Who directed Inception?

Graph path:
`Inception ← DIRECTED ← Christopher Nolan`

Answer:
> Inception was directed by Christopher Nolan.

## Tools
- Python
- Neo4j Desktop or Neo4j AuraDB
- Cypher
- Streamlit
- Neo4j Python Driver
- python-dotenv
- Optional OpenAI-compatible LLM API

## Limitations
- Small educational dataset.
- Entity recognition is rule-based in the baseline.
- Recommendation scoring is heuristic.
- No production authentication or multi-user session management.
- No automatic Cypher generation by an LLM in the baseline.

## Future Enhancements
- Add a larger movie dataset.
- Use an LLM to generate structured Cypher safely.
- Add Cypher validation and read-only query restrictions.
- Add vector embeddings for semantic retrieval.
- Add hybrid graph + vector RAG.
- Add conversation memory.
- Add evaluation metrics for retrieval accuracy and answer faithfulness.
- Add graph visualization.
- Add authentication and deployment.

## Conclusion
The project demonstrates how Neo4j can act as the retrieval layer for a RAG-style application. The graph structure makes movie relationships explicit, while the web interface gives users a simple natural-language way to explore the knowledge base.
