# Question Guide — CineGraph RAG

Use these questions in your demonstration. The wording can vary slightly, but the examples below are the safest.

## A. Movie → Director

**Question:** Who directed Inception?

Expected answer:
> Inception was directed by Christopher Nolan.

Cypher idea:
```cypher
MATCH (p:Person)-[:DIRECTED]->(m:Movie {title:$title})
RETURN p.name AS director;
```

## B. Movie → Cast

**Question:** Who acted in The Dark Knight?

The app retrieves actors connected with:
`(Person)-[:ACTED_IN]->(Movie)`

## C. Director → Filmography

**Question:** Movies directed by Christopher Nolan

The graph follows:
`(Person)-[:DIRECTED]->(Movie)`

## D. Actor → Movies

**Question:** Movies featuring Leonardo DiCaprio

The graph follows:
`(Person)-[:ACTED_IN]->(Movie)`

## E. Recommendations

**Question:** Recommend movies similar to Inception

The application looks for movies that share:
- genres,
- and, where available, cast members.

The score is a simple graph heuristic:
`sharedGenres × 2 + sharedActors + rating/10`

This is a transparent academic recommendation method.

## F. Genre search

**Question:** Show action movies

The graph follows:
`(Movie)-[:IN_GENRE]->(Genre)`

## G. Year search

**Question:** What movies are in 2014?

The graph filters:
`Movie.year = 2014`

## H. Good viva questions

### What is RAG?
Retrieval-Augmented Generation is an architecture where relevant external information is retrieved first and then used to produce a grounded natural-language answer.

### Why Neo4j?
Neo4j is a graph database. Movie relationships such as actor–movie–director–genre are naturally represented as nodes and relationships.

### What is Cypher?
Cypher is Neo4j's declarative query language for pattern matching in graphs.

### Why use a knowledge graph?
It preserves relationships explicitly. A query can traverse from a movie to its actors, director, genres and related movies.

### What prevents hallucination?
The application displays retrieved graph facts and uses those facts as the answer context. An LLM extension should be instructed to answer only from retrieved context.

### What is the limitation?
The bundled dataset is small and curated. A production system would need a larger dataset, stronger entity linking, query validation, caching, evaluation and access controls.
